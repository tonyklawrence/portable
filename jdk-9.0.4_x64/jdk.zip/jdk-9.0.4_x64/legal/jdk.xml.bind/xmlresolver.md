Please see ..\java.xml\xmlresolver.md
