function Offer(qualifier, discount) {
    this._qualifier = qualifier;
    this._discount = discount;
}

Offer.prototype.getTotalChargeableQuantity = function(quantity) {
    const discountedQuantity = (quantity) / this._qualifier
    
    return quantity - (parseInt(discountedQuantity) * this._discount);
}

export default Offer;