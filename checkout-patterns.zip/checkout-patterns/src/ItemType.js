export default function Item(name, price, offer) {
    this._price = price;
    this._offer = offer;
    this._name = name;

    this.calculateTotalPrice = (quantity) => {
        return this._getTotalChargeableQuantity(quantity) * this._price;
    }

    this.getPrice = () => this._price;
    this.getOffer = () => this._offer;

    this._getTotalChargeableQuantity = (quantity) => {
        return this._offer
        ? this._offer.getTotalChargeableQuantity(quantity)
        : quantity;
    }
}
