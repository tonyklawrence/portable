import Offer from './Offer';
import ItemType from './ItemType';

export const apple = new ItemType('apple', 12, new Offer(2, 1));

export const bananas = new ItemType('bananas', 51, new Offer(3, 1));

export const orange = new ItemType('orange', 32);

export const pineapple = new ItemType('pineapple', 95);

export const pen = new ItemType('pen', 22);
