import * as items from './Items';

export default function Order(quantities) {
    this._quantities = quantities;
    this._totalPrice = 0;

    this.calculateTotalPrice = () => {
        for (let item in this._quantities) {
            const validItem = items[item];
            if (validItem) {
                this._totalPrice += validItem.calculateTotalPrice(this._quantities[item]);
            }
        }
        return this._totalPrice;
    }
}
