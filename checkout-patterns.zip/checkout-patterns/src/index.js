import Checkout from './Checkout';

const checkout = new Checkout();
const order = ['apple', 'orange', 'apple', 'orange', 'pen', 'pineapple'];

console.log('Total: £', checkout.process(order));
