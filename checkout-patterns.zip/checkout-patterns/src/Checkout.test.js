import Checkout from './Checkout';
import Order from './Order';

jest.mock('./Order', () => {
  return jest.fn().mockImplementation(() => {
    return { calculateTotalPrice: jest.fn(() => 5) }
  })
});

const order = ['pen', 'orange', 'apple', 'orange', 'pen', 'pineapple'];
const orderQuantities = {
  pen: 2,
  orange: 2,
  apple: 1,
  pineapple: 1
};
beforeEach(() => {
  Order.mockClear();
})
describe('Checkout', () => {
  it('process returns total cost of order when basket is not empty', () => {
    const checkout = new Checkout();
    expect(checkout.process(order)).toEqual(5);
    expect(Order.mock.calls[0][0]).toEqual(orderQuantities)
  })

  it('process returns nothing when basket is empty', () => {
    const checkout = new Checkout();
    expect(checkout.process([])).toEqual(undefined);
    expect(Order).not.toHaveBeenCalled()
  })
});
