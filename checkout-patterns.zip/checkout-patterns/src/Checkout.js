import Order from './Order';

export default function Checkout() {

    this.process = (basket) => {
        if ( basket.length > 0) {
            const order = new Order(this._calculateQuantities(basket));
            return order.calculateTotalPrice();
        }
    }

    this._calculateQuantities = (basket) => {
        const groupedBasket = {};
        basket.map(item => {
            groupedBasket[item] = (groupedBasket[item] || 0) + 1;
        });
        return groupedBasket;
    };
    
}
