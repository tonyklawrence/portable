import Item from './ItemType';

const mockOffer = {
  getTotalChargeableQuantity: jest.fn(() => 3),
}
describe('Item', () => {
  it('getOffer returns offer', () => {
    const item = new Item('orange', 2, mockOffer)
    expect(item.getOffer()).toEqual(mockOffer);
    expect(item.getPrice()).toEqual(2);
  })

  it('getPrice returns price', () => {
    const item = new Item('orange', 2, mockOffer)
    expect(item.getPrice()).toEqual(2);
  })

  it('calculateTotalPrice returns the total cost for item after applying offer', () => {
    const item = new Item('orange', 2, mockOffer)
    expect(item.calculateTotalPrice(5)).toEqual(6);
  })

  it('calculateTotalPrice returns the total cost when there is no offer', () => {
    const item = new Item('orange', 2)
    expect(item.calculateTotalPrice(5)).toEqual(10);
  })
});
