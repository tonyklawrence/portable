import Offer from './Offer';

describe('Offer', () => {
  it('getTotalChargeableQuantity alculates the correct chargeable quantity when buy 1 get 1 free', () => {
    const offer = new Offer(2, 1);
    expect(offer.getTotalChargeableQuantity(4)).toEqual(2);
  })

  it('getTotalChargeableQuantity calculates the correct chargeable quantity when buy 3 get 1 free', () => {
    const offer = new Offer(3, 1);
    expect(offer.getTotalChargeableQuantity(4)).toEqual(3);
  })
});
