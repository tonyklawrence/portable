import Order from './Order';
import * as items from './Items';

jest.mock('./Items');

const mockItem = {
  calculateTotalPrice: jest.fn(() => 2),
}

items.pen = mockItem;
items.apple = mockItem;

beforeEach(() => {
  items.pen.calculateTotalPrice.mockClear();
  items.apple.calculateTotalPrice.mockClear();
});

describe('Order', () => {
  it('calculatesTotalPrice of order', () => {
    const quantity = {
      pen: 2,
      apple: 4,
    };
    const order = new Order(quantity);
    expect(order.calculateTotalPrice()).toEqual(4);
    expect(mockItem.calculateTotalPrice.mock.calls[0][0]).toEqual(quantity.pen);
    expect(mockItem.calculateTotalPrice.mock.calls[1][0]).toEqual(quantity.apple);
  })

  it('calculatesTotalPrice of order ignoring invalid items', () => {
    const quantity = {
      pen: 3,
      apple: 1,
      pencils: 5,
    };
    const order = new Order(quantity);
    expect(order.calculateTotalPrice()).toEqual(4);
    expect(mockItem.calculateTotalPrice).toHaveBeenCalledTimes(2);
    expect(mockItem.calculateTotalPrice.mock.calls[0][0]).toEqual(quantity.pen);
    expect(mockItem.calculateTotalPrice.mock.calls[1][0]).toEqual(quantity.apple);
  })
});
