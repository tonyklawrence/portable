# Checkout

Language: JavaScript (Node.js)

This was developed with node v10.16.0, npm 6.9.0, yarn 1.7.0

## Quick Start
In the root of this repo:

```
    $ yarn // or 
    $ npm install
```
To run the programme:

```
    $ yarn start // or 
    $ npm run start
```
In the index.js file, you can replace the list of item strings.

## Tests
To run tests and to see test coverage:
```
    $ yarn test //or 
    $ npm run test
```

To run tests in watch mode:
```
    $ yarn test:dev //or 
    $ npm run test:dev
```